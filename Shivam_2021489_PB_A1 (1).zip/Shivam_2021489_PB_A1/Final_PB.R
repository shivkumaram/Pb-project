#   Differential gene_exppression analysis with limma
library(GEOquery)
library(limma)
library(preprocessCore)
library(Biobase)
library(clusterProfiler)







# load series and platform data from GEO

Shivam <- getGEO("GSE19188", GSEMatrix =TRUE, AnnotGPL=TRUE)
fdata <- fData(Shivam[[1]])
fdata
pheno <- pData(Shivam[[1]])
if (length(Shivam) > 1) idx <- grep("GPL570", attr(Shivam, "names")) else idx <- 1
Shivam <- Shivam[[idx]]


# make proper column names to match toptable 
colnames(Shivam) <- make.names(colnames(Shivam))





#extracting gene expression data
gene_exp<-exprs(Shivam)
gene_exp

#view dimension of the data(EDA):
cat("Dimensions of gene expression data:", dim(gene_exp), "\n")
cat("Dimensions of phenotype data:", dim(pheno), "\n")

#view the structure of the data:
str(gene_exp)
str(pheno)

####EDA###
# Check for missing values in gene_exp matrix
sum(is.na(gene_exp))

###Preprocessing###
# Remove rows with missing values from gene_exp matrix
gene_exp <- gene_exp[complete.cases(gene_exp), ]

# Preprocessing: filter out lowly-expressed genes
gene_exp_filtered <- gene_exp[rowSums(gene_exp) > 0.5, ]

# Preprocessing: normalize the data using quantile normalization


gene_exp_norm <- normalize.quantiles(gene_exp_filtered)

rownames(gene_exp_norm) <- rownames(gene_exp_filtered)
colnames(gene_exp_norm) <- colnames(gene_exp_filtered)


#List data attributes:
# View data attributes
head(rownames(gene_exp_norm)) # List gene names
head(colnames(gene_exp_norm)) # List sample names
head(pheno) # View phenotype data
head(fdata)


#perform t-test and log fold change:
groupA <- pheno[pheno$`tissue type:ch1` == "healthy", ]
groupB <- pheno[pheno$`tissue type:ch1` != "healthy", ]

#divided into two group:
groupA_exprs <- gene_exp_norm[,groupA$geo_accession]
groupB_exprs <- gene_exp_norm[,groupB$geo_accession]

# Check if there are any genes left in the groups
if (ncol(groupA_exprs) == 0 || ncol(groupB_exprs) == 0) {
  stop("Not enough non-missing values for t-test")
}

exp_meansA <- rowMeans(groupA_exprs)
exp_meansB<- rowMeans(groupB_exprs)

fc<-(exp_meansA/exp_meansB) + 1

#log fold change:
logFC <- log2(abs(fc))

summary(logFC)

cat("Log fold change: ", logFC, "\n")


# initialize a vector to store t-test results
ttest_results <- numeric(nrow(gene_exp_norm))

# iterate over each row and perform t-test
for (i in 1:nrow(gene_exp_norm)) {
  ttest_results[i] <- t.test(groupA_exprs[i,], groupB_exprs[i,])$p.value
}

# print summary of t-test results
summary(ttest_results)

# initialize a vector to store p-values
pvals <- numeric(nrow(gene_exp_norm))

# iterate over each row and perform t-test
for (i in 1:nrow(gene_exp_norm)) {
  pvals[i] <- t.test(groupA_exprs[i,], groupB_exprs[i,])$p.value
}

# apply Holm's correction
corrected_pvals <- p.adjust(pvals, method = "holm")

# print summary of corrected p-values
summary(corrected_pvals)
corrected_pvals

# print p-values for significant genes
sig_genes <- gene_exp_norm[corrected_pvals < 0.05, ]
cat("Number of significant genes: ", nrow(sig_genes), "\n")
cat("Corrected p-values for significant genes: ", paste(round(corrected_pvals[corrected_pvals < 0.05], 5), collapse = ", "), "\n")


# create a data frame for log fold change and corrected p-values
volcano_data <- data.frame(logFC, -log10(corrected_pvals))

# plot volcano plot
plot(volcano_data$logFC, volcano_data$`-log10(corrected_pvals)`, 
     pch = 20, cex = 0.2, 
     col =ifelse( corrected_pvals < 0.05 & abs(volcano_data$logFC) > 1,"red","black"),
     main = "Volcano plot", xlab = "Log fold change", ylab = "-log10 (corrected p-value)",
     xlim = c(-6,2000), ylim = c(0, 8))

# add horizontal line for significance cutoff
abline(h = -log10(0.5), lty =2)

# add vertical lines for fold change cutoff
abline(v = 500, lty = 2)








# log2 transformation

qx <- as.numeric(quantile(gene_exp, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) ||
  (qx[6]-qx[1] > 50 && qx[2] > 0)
if (LogC) { gene_exp[which(gene_exp <= 0)] <- NaN
gene_expprs(Shivam) <- log2(gene_exp) }








# assign samples to groups and set up design matrix
sml <- ifelse(pheno$`tissue type:ch1` =="healthy", "healthy", "tumor")
gs <- factor(sml)
groups <- make.names(c("tumor","healthy"))
levels(gs) <- groups
Shivam$group <- gs
design <- model.matrix(~group + 0, Shivam)
colnames(design) <- levels(gs)

fit <- lmFit(Shivam, design)  # fit linear model

# set up contrasts of interest and recalculate model coefficients
cts <- paste(groups[1], groups[2], sep="-")
cont.matrix <- makeContrasts(contrasts=cts, levels=design)
fit2 <- contrasts.fit(fit, cont.matrix)

# compute statistics and table of top significant genes
fit2 <- eBayes(fit2, 0.01)
tT <- topTable(fit2, adjust="fdr", sort.by="B", number=250)

tT <- subset(tT, select=c("ID","adj.P.Val","P.Value","t","B","logFC","Gene.symbol","Gene.title"))
write.table(tT, file=stdout(), row.names=F, sep="\t")

# Visualize and quality control test results.
# Build histogram of P-values for all genes. Normal test
# assumption is that most genes are not differentially gene_exppressed.
tT2 <- topTable(fit2, adjust="fdr", sort.by="B", number=Inf)
hist(tT2$adj.P.Val, col = "grey", border = "white", xlab = "P-adj",
     ylab = "Number of genes", main = "P-adj value distribution")

# summarize test results as "up", "down" or "not gene_exppressed"
dT <- decideTests(fit2, adjust.method="fdr", p.value=0.05)



# create Q-Q plot for t-statistic
t.good <- which(!is.na(fit2$F)) # filter out bad probes
qqt(fit2$t[t.good], fit2$df.total[t.good], main="Moderated t statistic")

# volcano plot (log P-value vs log fold change)
colnames(fit2) # list contrast names
ct <- 1        # choose contrast of interest
volcanoplot(fit2, coef=ct, main=colnames(fit2)[ct], pch=20,
            highlight=length(which(dT[,ct]!=0)), names=rep('.', nrow(fit2)))
###################################################################



# Load required packages

library(GEOquery)

# Load series and platform data from GEO
GSE19188 <- getGEO("GSE19188", GSEMatrix = TRUE, AnnotGPL = TRUE)

# Extract gene expression data
gene_exp <- exprs(GSE19188[[1]])
#gene_1 <- exprs(Shivam[[1]])
# Display top 10 expressed genes
#top_genes <- rownames(gene_exp[order(-apply(gene_exp, 1, mean)),])[1:10]
top_genes <- rownames(gene_exp[order(-apply(gene_exp, 1, mean)),])[1:length(gene_exp)]

top_genes


library(org.Hs.eg.db)
library(gage)
library(pathview)
library(hgu133plus2.db)

geneset <- c( "207430_s_at" ,           "210297_s_at" ,           "228038_at" ,             "201839_s_at" ,           "223062_s_at" ,          
              "209125_at" ,             "205048_s_at" ,           "1552767_a_at" ,          "208650_s_at" ,           "204822_at" ,            
              "219148_at" ,             "204033_at" ,             "225846_at" ,             "222608_s_at" ,           "266_s_at" ,             
              "216379_x_at" ,           "223381_at" ,             "204455_at" ,             "209771_x_at" ,           "201291_s_at" ,          
              "230030_at" ,             "214612_x_at" ,           "218237_s_at" ,           "204641_at" ,             "209642_at" ,            
              "204268_at" ,             "209942_x_at" ,           "206165_s_at" ,           "231771_at" ,             "232067_at" ,            
              "209863_s_at" ,           "203764_at" ,             "201292_at" ,             "205347_s_at" ,           "228347_at" ,            
              "224428_s_at" ,           "203819_s_at" ,           "242881_x_at" ,           "222958_s_at" ,           "238593_at" ,            
              "204825_at" ,             "225645_at" ,             "201890_at" ,             "204962_s_at" ,           "225687_at" ,            
              "202095_s_at" ,           "222830_at" ,             "223229_at" ,             "208651_x_at" ,           "239069_s_at" ,          
              "225667_s_at" ,           "225601_at" ,             "218009_s_at" ,           "201689_s_at" ,           "228191_at" ,            
              "207165_at" ,             "205034_at" ,             "230193_at" ,             "206102_at" ,             "1552619_a_at" ,         
              "218835_at" ,             "204469_at" ,             "211756_at" ,             "232481_s_at" ,           "210052_s_at" ,          
              "203755_at" ,             "219121_s_at" ,           "205229_s_at" ,           "1569110_x_at" ,          "202954_at" ,            
              "203820_s_at" ,           "208079_s_at" ,           "217528_at" ,             "238673_at" ,             "222740_at" ,            
              "222680_s_at" ,           "228729_at" ,             "203358_s_at" ,           "202870_s_at" ,           "210559_s_at" ,          
              "217626_at" ,             "210387_at" ,             "207828_s_at" ,           "214580_x_at" ,           "230795_at" ,            
              "240304_s_at" ,           "44783_s_at" ,            "221854_at" ,             "219936_s_at" ,           "228455_at" ,            
              "232176_at" ,             "1554768_a_at" ,          "202597_at" ,             "228069_at" ,             "204146_at" ,            
              "37004_at" ,              "206204_at" ,             "214710_s_at" ,           "203362_s_at" ,           "218542_at" ,            
              "216548_x_at" ,           "202705_at" ,             "204026_s_at" ,           "218355_at" ,             "231192_at" ,            
              "202580_x_at" ,           "218585_s_at" ,           "222036_s_at" ,           "204086_at" ,             "225792_at" ,            
              "218888_s_at" ,           "209773_s_at" ,           "214023_x_at" ,           "219787_s_at" ,           "204092_s_at" ,          
              "211657_at" ,             "205064_at" ,             "235927_at" ,             "1568763_s_at" ,          "239954_at" ,            
              "203967_at" ,             "205394_at" ,             "203213_at" ,             "1555274_a_at" ,          "218782_s_at" ,          
              "203999_at" ,             "235456_at" ,             "209988_s_at" ,           "203744_at" ,             "224753_at" ,            
              "223471_at" ,             "229963_at" ,             "229490_s_at" ,           "209433_s_at" ,           "236462_at" ,            
              "206364_at" ,             "240046_at" ,             "219306_at" ,             "223556_at" ,             "202342_s_at" ,          
              "1556211_a_at" ,          "223687_s_at" ,           "223307_at" ,             "207469_s_at" ,           "202503_s_at" ,          
              "226456_at" ,             "213007_at" ,             "242517_at" ,             "209173_at" ,             "225655_at" ,            
              "236641_at" ,             "243495_s_at" ,           "235075_at" ,             "209351_at" ,             "232028_at" ,            
              "237107_at" ,             "232278_s_at" ,           "218186_at" ,             "218883_s_at" ,           "228273_at" ,            
              "205830_at" ,             "209720_s_at" ,           "224650_at" ,             "201690_s_at" ,           "228033_at" ,            
              "232097_at" ,             "226809_at" ,             "235609_at" ,             "228988_at" ,             "213226_at" ,            
              "218839_at" ,             "219978_s_at" ,           "209719_x_at" ,           "213248_at" ,             "202286_s_at" ,          
              "204798_at" ,             "208025_s_at" ,           "228393_s_at" ,           "203418_at" ,             "209714_s_at" ,          
              "206300_s_at" ,           "203214_x_at" ,           "209408_at" ,             "222039_at" ,             "230256_at" ,            
              "205190_at" ,             "205047_s_at" ,           "228157_at" ,             "204023_at" ,             "222848_at" ,            
              "217272_s_at" ,           "238029_s_at" ,           "209699_x_at" ,           "206550_s_at" ,           "219983_at" ,            
              "218726_at" ,             "235763_at" ,             "224320_s_at" ,           "222891_s_at" ,           "205916_at" ,            
              "220161_s_at" ,           "230002_at" ,             "235693_at" ,             "226189_at" ,             "206166_s_at" ,          
              "202489_s_at" ,           "214373_at" ,             "218039_at" ,             "213813_x_at" ,           "229551_x_at" ,          
              "233540_s_at" ,           "238632_at" ,             "230229_at" ,             "209529_at" ,             "212094_at" ,            
              "242476_at" ,             "235425_at" ,             "202107_s_at" ,           "218755_at" ,             "209810_at" ,            
              "220393_at" ,             "213599_at" ,             "241036_at" ,             "203560_at" ,             "210397_at" ,            
              "221521_s_at" ,           "205393_s_at" ,           "229796_at" ,             "227517_s_at" ,           "206291_at" , 
              "1555878_at" ,            "225834_at" ,             "213674_x_at" ,           "209891_at" ,             "213979_s_at" ,          
              "212281_s_at" ,           "1563130_a_at" ,          "235924_at" ,             "203397_s_at" ,           "222843_at" ,            
              "226269_at" ,             "1555758_a_at" ,          "218663_at" ,             "218145_at" ,             "220651_s_at" ,          
              "204444_at" ,             "204126_s_at" ,           "221047_s_at" ,           "232165_at" ,             "235476_at" ,            
              "235683_at" ,             "213796_at" ,             "219555_s_at" ,           "213523_at" ,             "226003_at" ,            
              "218499_at" ,             "219497_s_at" ,           "222906_at" ,             "232164_s_at" ,           "1559500_at" ,           
              "227256_at" ,             "238875_at" ,             "204734_at" ,             "235048_at" ,             "1555854_at" ,           
              "201897_s_at" ,           "202589_at" ,             "205339_at" ,             "228281_at" ,             "AFFX-r2-Bs-lys-5_at" ,  
              "235141_at" ,             "227875_at" ,             "238513_at" ,             "243134_at" ,             "226287_at" ,            
              "216594_x_at" ,           "205768_s_at" ,           "222774_s_at" ,           "1563111_a_at" ,          "219990_at" ,            
              "221520_s_at" ,           "219300_s_at" ,           "241811_x_at" ,           "203290_at" ,             "220658_s_at" ,          
              "210467_x_at" ,           "205046_at" ,             "213427_at" ,             "1569312_at" ,            "226535_at" ,            
              "204151_x_at" ,           "203699_s_at" ,           "221805_at" ,             "218332_at" ,             "207039_at" ,            
              "227350_at" ,             "226912_at" ,             "234986_at" ,             "230165_at" ,             "232082_x_at" ,          
              "227314_at" ,             "202094_at" ,             "203968_s_at" ,           "205051_s_at" ,           "205680_at" ,            
              "206385_s_at" ,           "206316_s_at" ,           "204162_at" ,             "1567045_at" ,            "231735_s_at" ,          
              "219544_at" ,             "209421_at" ,             "226479_at" ,             "222037_at" ,             "201820_at" ,            
              "1555241_at" ,            "228597_at" ,             "229704_at" ,             "215599_at" ,             "242859_at" ,            
              "240263_at" ,             "230058_at" ,             "223822_at" ,             "238778_at" ,             "202220_at" ,            
              "203924_at" ,             "202338_at" ,             "212282_at" ,             "1554572_a_at" ,          "226803_at" ,            
              "235117_at" ,             "229147_at" ,             "241031_at" ,             "222369_at" ,             "241453_at" ,            
              "218979_at" ,             "211276_at" ,             "227921_at" ,             "1553099_at" ,            "204260_at" ,            
              "224579_at" ,             "AFFX-r2-Bs-dap-5_at" ,   "237064_x_at" ,           "226653_at" ,             "242560_at" ,            
              "1559607_s_at" ,          "239001_at" ,             "226213_at" ,             "229899_s_at" ,           "AFFX-PheX-5_at" ,       
              "238623_at" ,             "225100_at" ,             "232489_at" ,             "220085_at" ,             "213008_at" ,            
              "218984_at" ,             "201688_s_at" ,           "242890_at" ,             "207746_at" ,             "225457_s_at" ,          
              "215629_s_at" ,           "204244_s_at" ,           "223700_at" ,             "1556035_s_at" ,          "239348_at" ,            
              "223721_s_at" ,           "226327_at" ,             "237388_at" ,             "225666_at" ,             "243149_at" ,            
              "1554452_a_at" ,          "204170_s_at" ,           "223530_at" ,             "235976_at" ,             "235542_at" ,            
              "228818_at" ,             "AFFX-DapX-5_at" ,        "242146_at" ,             "232099_at" ,             "242283_at" ,            
              "208103_s_at" ,           "237741_at" ,             "238768_at" ,             "213906_at" ,             "1556773_at" ,           
              "238666_at" ,             "200606_at" ,             "223038_s_at" ,           "210115_at" ,             "1552477_a_at" ,         
              "223861_at" ,             "204709_s_at" ,           "209053_s_at" ,           "225421_at" ,             "226610_at" ,            
              "206343_s_at" ,           "206164_at" ,             "218507_at" ,             "201417_at" ,             "237563_s_at" ,          
              "238902_at" ,             "203046_s_at" ,           "226556_at" ,             "234032_at" ,             "215779_s_at" ,          
              "227452_at" ,             "AFFX-ThrX-M_at" ,        "241990_at" ,             "235545_at" ,             "226029_at" ,            
              "236149_at" ,             "204767_s_at" ,           "239451_at" ,             "203209_at" ,             "222433_at" ,            
              "222624_s_at" ,           "203016_s_at" ,           "237086_at" ,             "206172_at" ,             "235700_at" ,            
              "210020_x_at" ,           "219959_at" ,             "218750_at" ,             "203987_at" ,             "1554408_a_at" ,         
              "230097_at" ,             "218349_s_at" ,           "1554242_a_at" ,          "228955_at" ,             "209498_at" ,            
              "214774_x_at" ,           "239091_at" ,             "226473_at" ,             "212141_at" ,             "242909_at" ,            
              "218252_at" ,             "205825_at" ,             "205194_at" ,             "210873_x_at" ,           "204614_at" ,            
              "204529_s_at" ,           "228099_at" ,             "218477_at" ,             "206613_s_at" ,           "AFFX-LysX-5_at" ,       
              "202890_at" ,             "1565566_a_at" ,          "239082_at" ,             "238549_at" ,             "AFFX-PheX-M_at" ,       
              "1559232_a_at" ,          "216450_x_at" ,           "212949_at" ,             "226248_s_at" ,           "219764_at" ,            
              "238807_at" ,             "241387_at" ,             "242671_at" ,             "222380_s_at" ,           "230763_at" ,            
              "213558_at" ,             "213610_s_at" ,           "205623_at" ,             "AFFX-r2-Bs-phe-5_at" ,   "228708_at" ,            
              "229292_at" ,             "219918_s_at" ,           "211653_x_at" ,           "204510_at" ,             "206504_at" , 
              "228262_at" ,             "218458_at" ,             "206307_s_at" ,           "244187_at" ,             "213605_s_at" ,          
              "209591_s_at" ,           "220969_s_at" ,           "214146_s_at" ,           "219376_at" ,             "206407_s_at" ,          
              "205311_at" ,             "1552622_s_at" ,          "239487_at" ,             "237864_at" ,             "204105_s_at" ,          
              "223642_at" ,             "1554696_s_at" ,          "204591_at" ,             "210715_s_at" ,           "235266_at" ,            
              "219588_s_at" ,           "225099_at" ,             "231851_at" ,             "233518_at" ,             "1554628_at" ,           
              "204992_s_at" ,           "216682_s_at" ,           "228654_at" ,             "201014_s_at" ,           "226431_at" ,            
              "231145_at" ,             "210053_at" ,             "228494_at" ,             "221646_s_at" ,           "216563_at" ,            
              "229947_at" ,             "229377_at" ,             "224839_s_at" ,           "219000_s_at" ,           "205594_at" ,            
              "218875_s_at" ,           "1562102_at" ,            "226444_at" ,             "222634_s_at" ,           "1552291_at" ,           
              "218829_s_at" ,           "220239_at" ,             "219995_s_at" ,           "209126_x_at" ,           "228930_at" ,            
              "213695_at" ,             "219976_at" ,             "231855_at" ,             "229099_at" ,             "243000_at" ,            
              "204603_at" ,             "214431_at" ,             "203228_at" ,             "203096_s_at" ,           "235148_at" ,            
              "211519_s_at" ,           "201478_s_at" ,           "213793_s_at" ,           "218397_at" ,             "226478_at" ,            
              "226363_at" ,             "210871_x_at" ,           "AFFX-r2-Bs-thr-M_s_at" , "209815_at" ,             "201867_s_at" ,          
              "214455_at" ,             "226121_at" ,             "227545_at" ,             "236840_at" ,             "209464_at" ,            
              "204240_s_at" ,           "210983_s_at" ,           "33323_r_at" ,            "239164_at" ,             "212279_at" ,            
              "227249_at" ,             "241885_at" ,             "205014_at" ,             "228906_at" ,             "236696_at" ,            
              "212454_x_at" ,           "238075_at" ,             "214642_x_at" ,           "235509_at" ,             "241418_at" ,            
              "220011_at" ,             "234464_s_at" ,           "205240_at" ,             "223403_s_at" ,           "221264_s_at" ,          
              "225444_at" ,             "213150_at" ,             "225455_at" ,             "220012_at" ,             "235587_at" ,            
              "221536_s_at" ,           "212020_s_at" ,           "226365_at" ,             "229546_at" ,             "243305_at" ,            
              "214804_at" ,             "227801_at" ,             "205959_at" ,             "218392_x_at" ,           "227751_at" ,            
              "1554557_at" ,            "231311_at" ,             "242260_at" ,             "1555867_at" ,            "AFFX-r2-Bs-phe-M_at" ,  
              "217678_at" ,             "1553956_at" ,            "228323_at" ,             "227461_at" ,             "241954_at" ,            
              "230892_at" ,             "209398_at" ,             "213506_at" ,             "226446_at" ,             "219612_s_at" ,          
              "231331_at" ,             "212952_at" ,             "227220_at" ,             "229787_s_at" ,           "226350_at" ,            
              "206912_at" ,             "243918_at" ,             "210505_at" ,             "201026_at" ,             "1553575_at" ,           
              "205709_s_at" ,           "236224_at" ,             "224888_at" ,             "1564164_at" ,            "227892_at" ,            
              "1552283_s_at" ,          "226661_at" ,             "203145_at" ,             "226611_s_at" ,           "231647_s_at" ,          
              "1553413_at" ,            "221909_at" ,             "205625_s_at" ,           "203017_s_at" ,           "209434_s_at" ,          
              "214603_at" ,             "1560926_at" ,            "229672_at" ,             "236439_at" ,             "204720_s_at" ,          
              "213310_at" ,             "223577_x_at" ,           "210029_at" ,             "223915_at" ,             "226245_at" ,            
              "211906_s_at" ,           "229912_at" ,             "239155_at" ,             "212022_s_at" ,           "203184_at" ,            
              "1558695_at" ,            "218847_at" ,             "220431_at" ,             "223883_s_at" ,           "209921_at" ,            
              "204700_x_at" ,           "217506_at" ,             "241705_at" ,             "216623_x_at" ,           "220147_s_at" ,          
              "210612_s_at" ,           "226600_at" ,             "236223_s_at" ,           "204728_s_at" ,           "233463_at" ,            
              "204318_s_at" ,           "205063_at" ,             "224444_s_at" ,           "213089_at" ,             "AFFX-LysX-3_at" ,       
              "205569_at" ,             "203087_s_at" ,           "210098_s_at" ,           "224185_at" ,             "204712_at" ,            
              "231953_at" ,             "201849_at" ,             "241682_at" ,             "244246_at" ,             "240296_at" ,            
              "219389_at" ,             "235112_at" ,             "235374_at" ,             "1569320_at" ,            "228999_at" ,            
              "225485_at" ,             "242009_at" ,             "244633_at" ,             "221922_at" ,             "214596_at" ,            
              "206023_at" ,             "210074_at" ,             "221258_s_at" ,           "235463_s_at" ,           "232528_at" ,            
              "204675_at" ,             "214639_s_at" ,           "239049_at" ,             "218176_at" ,             "209560_s_at" ,          
              "205282_at" ,             "211361_s_at" ,           "224610_at" ,             "209709_s_at" ,           "223490_s_at" ,          
              "213721_at" ,             "219928_s_at" ,           "224367_at" ,             "1555225_at" ,            "218894_s_at" ,          
              "231784_s_at" ,           "222018_at" ,             "226726_at" ,             "1556194_a_at" ,          "227884_at" ,            
              "230387_at" ,             "229543_at" ,             "227943_at" ,             "205968_at" ,             "204531_s_at" ,
              "1565620_at" ,            "205687_at" ,             "221919_at" ,             "243278_at" ,             "206110_at" ,            
              "1559078_at" ,            "217164_at" ,             "217744_s_at" ,           "226458_at" ,             "AFFX-r2-Bs-dap-M_at" ,  
              "213913_s_at" ,           "234326_at" ,             "222077_s_at" ,           "205543_at" ,             "229360_at" ,            
              "235918_x_at" ,           "207739_s_at" ,           "AFFX-r2-Bs-thr-3_s_at" , "238755_at" ,             "204667_at" ,            
              "223278_at" ,             "235803_at" ,             "219498_s_at" ,           "220840_s_at" ,           "239413_at" ,            
              "1557804_at" ,            "234970_at" ,             "204460_s_at" ,           "243332_at" ,             "226067_at" ,            
              "222027_at" ,             "1552519_at" ,            "222962_s_at" ,           "231240_at" ,             "229305_at" ,            
              "208795_s_at" ,           "239243_at" ,             "242877_at" ,             "219683_at" ,             "229538_s_at" ,          
              "1558922_at" ,            "219493_at" ,             "1567213_at" ,            "219512_at" ,             "213285_at" ,            
              "222549_at" ,             "220030_at" ,             "236924_at" ,             "235092_at" ,             "235363_at" ,            
              "228565_at" ,             "243462_s_at" ,           "226670_s_at" ,           "225540_at" ,             "1554008_at" ,           
              "215450_at" ,             "201286_at" ,             "AFFX-DapX-M_at" ,        "228030_at" ,             "228401_at" ,            
              "230304_at" ,             "1555920_at" ,            "205769_at" ,             "228931_at" ,             "209064_x_at" ,          
              "215786_at" ,             "242968_at" ,             "223704_s_at" ,           "228392_at" ,             "1558164_s_at" ,         
              "242261_at" ,             "211767_at" ,             "AFFX-r2-Bs-lys-M_at" ,   "205739_x_at" ,           "1556613_s_at" ,         
              "201853_s_at" ,           "205909_at" ,             "218350_s_at" ,           "230493_at" ,             "201645_at" ,            
              "218842_at" ,             "206510_at" ,             "214052_x_at" ,           "242343_x_at" ,           "239131_at" ,            
              "240908_at" ,             "213927_at" ,             "217820_s_at" ,           "238295_at" ,             "1557360_at" ,           
              "201111_at" ,             "224974_at" ,             "222623_s_at" ,           "225300_at" ,             "223582_at" ,            
              "213410_at" ,             "226242_at" ,             "1556064_at" ,            "237062_at" ,             "213454_at" ,            
              "230337_at" ,             "1566257_at" ,            "243109_at" ,             "225107_at" ,             "232145_at" ,            
              "238069_at" ,             "235253_at" ,             "AFFX-r2-Bs-phe-3_at" ,   "224467_s_at" ,           "219388_at" ,            
              "225711_at" ,             "1567912_s_at" ,          "204866_at" ,             "213350_at" ,             "214221_at" ,            
              "201636_at" ,             "219296_at" ,             "230712_at" ,             "242488_at" ,             "AFFX-r2-Bs-thr-5_s_at" ,
              "217520_x_at" ,           "219258_at" ,             "214060_at" ,             "244811_at" ,             "219105_x_at" ,          
              "229610_at" ,             "232889_at" ,             "235926_at" ,             "222875_at" ,             "229665_at" ,            
              "221436_s_at" ,           "1552766_at" ,            "AFFX-DapX-3_at" ,        "1562497_at" ,            "1568857_a_at" ,         
              "204920_at" ,             "203625_x_at" ,           "1559038_at" ,            "218115_at" ,             "238651_at" ,            
              "230028_at" ,             "235009_at" ,             "1557810_at" ,            "225786_at" ,             "227134_at" ,            
              "AFFX-ThrX-3_at" ,        "223254_s_at" ,           "237291_at" ,             "231956_at" ,             "202979_s_at" ,          
              "236766_at" ,             "232541_at" ,             "204612_at" ,             "244427_at" ,             "212021_s_at" ,          
              "200783_s_at" ,           "204353_s_at" ,           "209172_s_at" ,           "203798_s_at" ,           "203413_at" ,            
              "243249_at" ,             "242797_x_at" ,           "1555501_s_at" ,          "219037_at" ,             "1555996_s_at" ,         
              "243546_at" ,             "226325_at" ,             "235138_at" ,             "226281_at" ,             "222250_s_at" ,          
              "1555243_x_at" ,          "213742_at" ,             "205352_at" ,             "227506_at" ,             "229793_at" ,            
              "227372_s_at" ,           "202633_at" ,             "208694_at" ,             "229724_at" ,             "221960_s_at" ,          
              "202666_s_at" ,           "223255_at" ,             "224365_s_at" ,           "243299_at" ,             "214850_at" ,            
              "229400_at" ,             "222392_x_at" ,           "224308_s_at" ,           "218982_s_at" ,           "235244_at" ,            
              "223515_s_at" ,           "209987_s_at" ,           "239148_at" ,             "241716_at" ,             "205053_at" ,            
              "1553677_a_at" ,          "212850_s_at" ,           "229455_at" ,             "204286_s_at" ,           "1557433_at" ,           
              "202744_at" ,             "202483_s_at" ,           "235026_at" ,             "232629_at" ,             "228245_s_at" ,          
              "212649_at" ,             "237216_at" ,             "1560271_at" ,            "1568983_a_at" ,          "238646_at" ,            
              "214313_s_at" ,           "242546_at" ,             "238970_at" ,             "218792_s_at" ,           "225436_at" ,            
              "227371_at" ,             "1553672_at" ,            "210355_at" ,             "207519_at" ,             "239798_at" ,   
              "1568834_s_at" ,          "220607_x_at" ,           "239619_at" ,             "217901_at" ,             "201287_s_at" ,          
              "230323_s_at" ,           "222746_s_at" ,           "235201_at" ,             "209260_at" ,             "226190_at" ,            
              "234331_s_at" ,           "203208_s_at" ,           "207325_x_at" ,           "1554588_a_at" ,          "243589_at" ,            
              "214254_at" ,             "210827_s_at" ,           "211024_s_at" ,           "205169_at" ,             "235126_at" ,            
              "232466_at" ,             "225278_at" ,             "239841_at" ,             "1557738_at" ,            "1552310_at" ,           
              "1558700_s_at" ,          "235053_at" ,             "205677_s_at" ,           "AFFX-LysX-M_at" ,        "219317_at" ,            
              "213951_s_at" ,           "1552921_a_at" ,          "205595_at" ,             "218976_at" ,             "222803_at" ,            
              "227689_at" ,             "1557352_at" ,            "219010_at" ,             "220459_at" ,             "204237_at" ,            
              "218209_s_at" ,           "202911_at" ,             "208546_x_at" ,           "211715_s_at" ,           "226520_at" ,            
              "201467_s_at" ,           "219166_at" ,             "AFFX-r2-Bs-lys-3_at" ,   "210701_at" ,             "204886_at" ,            
              "226936_at" ,             "213424_at" ,             "228570_at" ,             "220892_s_at" ,           "213954_at" ,            
              "227282_at" ,             "205167_s_at" ,           "227255_at" ,             "219960_s_at" ,           "214061_at" ,            
              "214877_at" ,             "202016_at" ,             "219494_at" ,             "204465_s_at" ,           "222040_at" ,            
              "235716_at" ,             "222771_s_at" ,           "226999_at" ,             "217974_at" ,             "208051_s_at" ,          
              "231484_at" ,             "229398_at" ,             "226320_at" ,             "204887_s_at"  )
enrich_result <- enrichGO(gene = geneset, 
                          OrgDb = "hgu133plus2.db", 
                          keyType = "PROBEID", 
                          ont = "BP", 
                          pAdjustMethod = "BH", 
                          pvalueCutoff = 0.05, 
                          qvalueCutoff = 0.1)

enrich_result
# Plot the bar plot
barplot(enrich_result@result$Count, 
        main = "Enrichment Analysis",
        xlab = "GO Term",
        ylab = "Number of Genes",
        names.arg = enrich_result@result$Description,
        col = "lightblue",
        las = 2,
        ylim = c(0, max(enrich_result@result$Count)*1.1))







