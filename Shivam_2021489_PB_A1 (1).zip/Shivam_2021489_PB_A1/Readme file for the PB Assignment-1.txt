Readme file for the PB Assignment-1:

Ques1:
Shivam <- getGEO("GSE19188", GSEMatrix =TRUE, AnnotGPL=TRUE)
fdata <- fData(Shivam[[1]])
fdata
pheno <- pData(Shivam[[1]])
if (length(Shivam) > 1) idx <- grep("GPL570", attr(Shivam, "names")) else idx <- 1
Shivam <- Shivam[[idx]]

This code downloads gene expression data from the GEO database for the dataset GSE19188 and extracts the gene expression values and sample-level data. It also downloads platform annotation data for the Affymetrix Human Genome U133 Plus 2.0 Array (GPL570), which was used to generate the gene expression data
##########################################################################################################################################
Ques2:
This code extracts gene expression data from the Shivam object and preprocesses it for downstream analysis. The steps followed in the code are explained below:

Gene Expression Data Extraction
The gene expression data is extracted from the Shivam object using the exprs() function and stored in the gene_exp variable.

Exploratory Data Analysis (EDA)
The dimensions of the gene expression and phenotype data are displayed using the dim() function. The structure of the gene expression and phenotype data is displayed using the str() function. Missing values in the gene expression matrix are checked using the is.na() and sum() functions.

Preprocessing
Rows with missing values in the gene expression matrix are removed using the complete.cases() function. Genes with low expression levels are filtered out using the rowSums() function. Quantile normalization is applied to the filtered gene expression data using the normalize.quantiles() function. The row and column names of the normalized gene expression data are set to match the filtered gene expression data.

List Data Attributes
The gene names and sample names are listed using the rownames() and colnames() functions, respectively. The phenotype and fdata (feature data) are also displayed using the head() function.

Overall, this code is an example of preprocessing gene expression data for downstream analysis. The code can be customized and modified based on the specific needs of the analysis.
##########################################################################################################################################
Ques3>
Log2 Transformation
The code first calculates the quantiles of the gene expression data using the quantile() function. The as.numeric() function is used to convert the quantiles into a numeric vector.

Next, the code checks if a log2 transformation is necessary. This is done by checking if the maximum value of the gene expression data is greater than 100 or if the difference between the 99th and 1st quantiles is greater than 50 and the 25th quantile is greater than 0. If either of these conditions is met, a log2 transformation is applied to the gene expression data using the log2() function.

Any gene expression values less than or equal to zero are replaced with NaN using the which() and <- operators.

Conclusion
This code is an example of how to perform a log2 transformation on gene expression data. It can be customized and modified based on the specific needs of the analysis.

Explaination:
Finding biologically significant changes in gene expression from microarray data is difficult because it frequently includes a wide range of expression values. By reducing the dynamic range of the expression values, the method of log transformation is frequently used to normalise and stabilise the data. The following are some effects of log change on microarray data:
Dynamic range compression is the first
Normalization 2.
3. symmetrical distribution
4. Enhanced comparison

--->  When those samples are normalised through the use of log transformation, the amount of gene expression is brought closer to the normalised values and, when plotted, has a normal-like distribution. 

When data are left or right skewed, it is also done to help minimise variation in the data, which aids in visualisation and pattern recognition.
##########################################################################################################################################
Ques4>
This code performs a t-test and calculates the log fold change between two groups of gene expression data. The first few lines of code divide the data into two groups, groupA (containing healthy tissue samples) and groupB (containing non-healthy(tumor) tissue samples). The code then calculates the mean expression values for each gene in each group and uses them to calculate the log fold change.

The next section of the code performs a t-test on each gene to determine if the difference in expression between the two groups is statistically significant. The p-values are adjusted using Holm's correction for multiple testing.

Finally, the code creates a volcano plot to visualize the log fold change and significance of each gene.

To create a single readme file, you can combine the explanation of the code above with the code itself, along with any additional information or context about the data and analysis being performed.
##########################################################################################################################################Ques5>
differential expression analysis using the limma package:
The main steps of the analysis are as follows:

Data preprocessing: removing low quality probes, normalizing and log-transforming gene expression values.
Setting up a linear model to test for differential gene expression between groups.
Computing statistics and identifying top significant genes.
Visualizing the results with various plots including a histogram of adjusted p-values, Q-Q plot for t-statistic, and a volcano plot.
Please note that this code is intended as a template and may need to be modified depending on the specific dataset and research question.
###########################################################################################################################################
Ques6>
Each experiment uses and needs a certain level of statistical significance; sometimes a p value of 0.01 is used, other times a p value of 0.05 is. Log (FC) cutoffs and p value cutoffs are completely dependent on the analysis and the results we would like to obtain. 

However, as a rule of thumb, we chose a p value of 0.05 and a log(FC) cutoff of greater than 1 because we believe that the sample of genes taken will show at least a 2-fold change in expression when the two groups are compared and because observing some biological changes in gene expression level can only be measured in that case.
--> corrected_pvals < 0.05 & abs(volcano_data$logFC) > 1

Even so, the log(FC) cutoff relies on the strategy and result
##########################################################################################################################################Ques7>
Ques 7> firstly, we are e gene expression data matrix by the mean expression value across all samples, and then extracts the names of all the genes in the dataset.

then all the genes are stored in vector geneset. then we are finding the enrich result as following code:
enrich_result <- enrichGO(gene = geneset, 
                          OrgDb = "hgu133plus2.db", 
                          keyType = "PROBEID", 
                          ont = "BP", 
                          pAdjustMethod = "BH", 
                          pvalueCutoff = 0.05, 
                          qvalueCutoff = 0.1)
#####################################################################################
Ques 8>
gene: A vector of gene identifiers (e.g. gene symbols, Entrez IDs) that you want to test for enrichment. This could be a subset of all genes in your dataset or all genes in the genome.
OrgDb: The name of the organism-specific annotation package to be used for mapping the gene IDs to their corresponding pathways or GO terms. In this case, it's "hgu133plus2.db", which is an annotation package for the Human Genome U133 Plus 2.0 Array.
keyType: The type of identifier used to map the gene IDs to the annotation database. In this case, it's "PROBEID", which corresponds to the probe set IDs on the U133 Plus 2.0 array.
ont: The ontology (or type of annotation) to be used for enrichment analysis. In this case, it's "BP", which stands for biological process ontology of Gene Ontology (GO).
pAdjustMethod: The method used to adjust for multiple testing when calculating the p-values. In this case, it's "BH", which stands for the Benjamini-Hochberg method for controlling the false discovery rate.
pvalueCutoff: The threshold for the p-value cutoff used to determine significant enrichment. Genesets with adjusted p-values less than or equal to this cutoff will be considered significantly enriched.
qvalueCutoff: The threshold for the q-value cutoff used to determine significant enrichment. Genesets with adjusted q-values less than or equal to this cutoff will be considered significantly enriched.
Overall, this code is designed to identify Gene Ontology (GO) Biological Processes that are enriched in the provided gene set. It does so by comparing the gene set against a database of known biological pathways or Gene Ontology (GO) terms using statistical methods to determine if any pathways or GO terms are overrepresented in the gene set.
###################################################################################################
Ques9>
The actions I took following the enrichment study are:
 
   a) Examining the enriched pathways map 
   b) Interpret the pathways: Examine the specific genes or proteins that make up each enhanced pathway. 
   c) Determining the important pathways: Determine the biologically significant or significant pathways in relation to your study question.

   d) Original ideas 
   c) Verifying the results

We can observe the graph is exponentially decreasing and then slithly decrease for the different gene set in bar plot and also we can see the egregation GO Term has has 45 no of genes which is maximum number  and essetation  and imigration has min no. of genes around 2-4.